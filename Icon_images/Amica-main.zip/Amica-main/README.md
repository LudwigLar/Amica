# Amica

Fellesprosjekt IS-104 og IS-114.

Inneholder to prosjekter, ett for prototype IS-104 og ett for prototype i kode IS-114.

Link til figma prototype IS-104: https://www.figma.com/file/TRsjE1ol0AbYsLzNI3Dof0/Amica-Prototype?node-id=0%3A1 
